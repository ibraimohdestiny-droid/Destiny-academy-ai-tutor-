import "dotenv/config";
import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
const port = Number(process.env.PORT || 10000);
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(cors({ origin: process.env.ALLOWED_ORIGIN || true }));
app.use(express.json({ limit: "50kb" }));
app.use(express.static("."));

const SYSTEM_PROMPT = `
You are Destiny Academy AI Tutor, a friendly educational assistant.

Destiny Academy teaches Microsoft Word, Microsoft Excel, PowerPoint, CorelDRAW,
GitHub, Web Development, Programming, and Artificial Intelligence.

Teach clearly and step by step. Use simple language, examples, and short practice tasks.
Encourage students to understand their work rather than helping them cheat on graded work.
Do not ask for or reveal passwords, API keys, private account information, or other secrets.
Keep answers appropriate for school-age learners.
`;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "Destiny Academy AI Tutor" });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "AI Tutor is not configured yet." });
    }

    const { message, history = [] } = req.body ?? {};
    if (typeof message !== "string" || !message.trim()) {
      return res.status(400).json({ error: "Please enter a question." });
    }

    const safeHistory = Array.isArray(history)
      ? history
          .filter(x => x && (x.role === "user" || x.role === "assistant") && typeof x.content === "string")
          .slice(-10)
      : [];

    const response = await client.responses.create({
      model: "gpt-6-astra",
      instructions: SYSTEM_PROMPT,
      input: [...safeHistory, { role: "user", content: message.trim() }]
    });

    res.json({ reply: response.output_text });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "The AI Tutor could not respond right now. Please try again." });
  }
});

app.listen(port, "0.0.0.0", () => {
  console.log(`Destiny Academy AI Tutor listening on port ${port}`);
});
